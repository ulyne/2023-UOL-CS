function setup(){    
    createCanvas(500,500);
}

function draw()
{
    //noFillDemo();
    //strokeWeightDemo();
    //strokeDemo();
    //noStrokDemo();
    //ellipseDemo();
    //lineDemo();
    //triangleDemo();
    //pointDemo1();
    //pointDemo2();
    //shapeDemo();
}

function shapeDemo(){
    background(200);
    beginShape();
    vertex(30,20);
    vertex(85,20);
    vertex(85,75);
    vertex(30,75);
    endShape(CLOSE);
    
}

function pointDemo2(){
    background(200);
    stroke("purple");
    strokeWeight(10);
    point(30,20);
    point(85,20);
    point(85,75);
    point(30,75);
    
}

function pointDemo1(){
    background(200);
    point(30,20);
    point(85,20);
    point(85,75);
    point(30,75);
}

function triangleDemo(){
    background(200);
    triangle(30,75,58,20,86,75);    
}

function lineDemo(){
    background(200);
    stroke(0);
    line(30,20,85,20);
    stroke(126);
    line(85,20,85,75);
    stroke(255);
    line(85,75,30,75);
}

function ellipseDemo(){
    
    background(200);
    ellipse(56,46,55,55);
    ellipse(56,146,30,55);
    ellipse(156,46,55,20);
}

function noStrokDemo(){
    background(200);
    noStroke();
    rect(20,20,60,60);
}


function strokDemo(){
    background(200);
    strokeWeight(4);
    stroke(255,0,0);
    rect(20,20,60,60);
}

function strokeWeightDemo(){
    background(200);
    strokeWeight(1);
    line(20,20,80,20);
    strokeWeight(4);
    line(20,40,80,40);
    strokeWeight(10);
    line(20,70,80,70);    
}

function noFillDemo()
{
    background(200);
    fill(255);
    rect(15,10,55,55);
    noFill();
    rect(20,20,60,60);
}