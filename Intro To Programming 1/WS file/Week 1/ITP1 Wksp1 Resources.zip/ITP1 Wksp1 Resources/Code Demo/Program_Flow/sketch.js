function setup()
{
	createCanvas(600, 600);
    fill(255, 0, 0);
}

function draw()
{
    //This rect is only red in colour for the first frame
	rect(100, 100, 200, 200);

	fill(0, 0, 255);
	rect(200, 200, 200, 200);
    
}